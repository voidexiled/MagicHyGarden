package com.voidexiled.magichygarden;

import com.hypixel.hytale.builtin.adventure.farming.FarmingPlugin;
import com.hypixel.hytale.builtin.adventure.farming.states.FarmingBlock;
import com.hypixel.hytale.component.ComponentType;
import com.hypixel.hytale.logger.HytaleLogger;
import com.hypixel.hytale.server.core.asset.type.blocktype.config.farming.GrowthModifierAsset;
import com.hypixel.hytale.server.core.modules.interaction.interaction.config.Interaction;
import com.hypixel.hytale.server.core.plugin.JavaPlugin;
import com.hypixel.hytale.server.core.plugin.JavaPluginInit;
import com.hypixel.hytale.server.core.universe.world.storage.ChunkStore;
import com.voidexiled.magichygarden.commands.crop.CropCommand;
import com.voidexiled.magichygarden.features.farming.components.MghgCropData;
import com.voidexiled.magichygarden.features.farming.interactions.MghgBlockSecondaryInteraction;
import com.voidexiled.magichygarden.features.farming.interactions.MghgHarvestCropInteraction;
import com.voidexiled.magichygarden.features.farming.modifiers.MghgCropGrowthModifierAsset;
import com.voidexiled.magichygarden.features.farming.systems.MghgMatureCropMutationTickingSystem;
import com.voidexiled.magichygarden.features.farming.systems.MghgOnFarmBlockAddedSystem;
import com.voidexiled.magichygarden.features.farming.systems.MghgRehydrateCropDataOnPlaceSystem;

public class MagicHyGardenPlugin extends JavaPlugin {
    private static MagicHyGardenPlugin INSTANCE;

    private static final HytaleLogger LOGGER = HytaleLogger.forEnclosingClass();

    // Component Types
    private ComponentType<ChunkStore, MghgCropData> mghgCropDataComponentType;

    // Constructors
    public MagicHyGardenPlugin(JavaPluginInit init) {
        super(init);
        INSTANCE = this;
        LOGGER.atInfo().log("Hello from %s version %s", this.getName(), this.getManifest().getVersion().toString());
    }

    // Override Methods
    @Override
    protected void setup() {
        this.getCodecRegistry(Interaction.CODEC)
                .register("MGHG_HarvestCrop", MghgHarvestCropInteraction.class, MghgHarvestCropInteraction.CODEC);
        this.getCodecRegistry(Interaction.CODEC)
                .register("MGHG_Block_Secondary", MghgBlockSecondaryInteraction.class, MghgBlockSecondaryInteraction.CODEC);

        // Register Commands
        this.getCommandRegistry().registerCommand(new CropCommand());

        // Register Component Codecs
        this.mghgCropDataComponentType = this.getChunkStoreRegistry()
                .registerComponent(MghgCropData.class, "MGHG_CropData", MghgCropData.CODEC);


        //this.getEntityStoreRegistry().registerSystem(
        //        new MghgRehydrateCropDataOnPlaceSystem(this.mghgCropDataComponentType)
        //);

        getCodecRegistry(GrowthModifierAsset.CODEC)
                .register("MGHG_CropGrowth", MghgCropGrowthModifierAsset.class, MghgCropGrowthModifierAsset.CODEC);
    }

    @Override
    protected void start() {
        FarmingPlugin farmingPlugin =
                FarmingPlugin.get();

        if (farmingPlugin == null) {
            LOGGER.atWarning().log("FarmingPlugin.get() es null en start(); no se registrará MghgOnFarmBlockAddedSystem.");
            return;
        }

        ComponentType<ChunkStore, FarmingBlock> farmingBlockType =
                farmingPlugin.getFarmingBlockComponentType();

        // Farm Block Added System ChunkStore
        // minSize, maxSize, goldChance, rainbowChance
        // chances when farm block is added
        this.getChunkStoreRegistry().registerSystem(
                new MghgOnFarmBlockAddedSystem(
                        farmingBlockType,
                        this.mghgCropDataComponentType,
                        50, 100,
                        0.005f, 0.0005f
                )
        );

        this.getEntityStoreRegistry().registerSystem(
                new com.voidexiled.magichygarden.features.farming.systems.MghgRehydrateCropDataOnPlaceSystem(
                        this.mghgCropDataComponentType
                )
        );

        this.getChunkStoreRegistry().registerSystem(
                new MghgMatureCropMutationTickingSystem(
                        farmingBlockType,
                        this.mghgCropDataComponentType,
                        5,          // cooldown seconds (ejemplo)
                        0.50,       // rain chance
                        0.50,       // snow chance
                        0.50,       // frozen chance
                        new String[]{"Zone1_Rain"},
                        new String[]{"Zone1_Snow"},
                        new String[]{"Zone1_Rain_Snow"}
                )
        );


    }


    // Methods

    public ComponentType<ChunkStore, MghgCropData> getMghgCropDataComponentType() {
        return mghgCropDataComponentType;
    }

    public static MagicHyGardenPlugin get() {
        return INSTANCE;
    }
}

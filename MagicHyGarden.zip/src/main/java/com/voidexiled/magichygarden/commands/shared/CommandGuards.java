package com.voidexiled.magichygarden.commands.shared;

public class CommandGuards {
}

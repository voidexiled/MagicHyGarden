package com.voidexiled.magichygarden.features.farming.state;

public enum ClimateMutation {
    NONE,
    RAIN,
    SNOW,
    FROZEN
}

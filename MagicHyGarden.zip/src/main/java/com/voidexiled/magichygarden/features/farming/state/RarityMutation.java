package com.voidexiled.magichygarden.features.farming.state;

public enum RarityMutation {
    NONE,
    GOLD,
    RAINBOW
}

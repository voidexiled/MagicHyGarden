package com.voidexiled.magichygarden.features.farming.systems;

import com.hypixel.hytale.component.*;
import com.hypixel.hytale.component.query.Query;
import com.hypixel.hytale.component.system.EntityEventSystem;
import com.hypixel.hytale.logger.HytaleLogger;
import com.hypixel.hytale.math.util.ChunkUtil;
import com.hypixel.hytale.math.vector.Vector3i;
import com.hypixel.hytale.server.core.asset.type.blocktype.config.BlockType;
import com.hypixel.hytale.server.core.event.events.ecs.PlaceBlockEvent;
import com.hypixel.hytale.server.core.inventory.ItemStack;
import com.hypixel.hytale.server.core.modules.time.WorldTimeResource;
import com.hypixel.hytale.server.core.universe.world.World;
import com.hypixel.hytale.server.core.universe.world.chunk.WorldChunk;
import com.hypixel.hytale.server.core.universe.world.storage.ChunkStore;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import com.voidexiled.magichygarden.features.farming.components.MghgCropData;
import com.voidexiled.magichygarden.features.farming.items.MghgCropMeta;
import com.voidexiled.magichygarden.features.farming.state.ClimateMutation;
import com.voidexiled.magichygarden.features.farming.state.RarityMutation;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import javax.annotation.Nonnull;
import java.time.Instant;
import java.util.Locale;

public final class MghgRehydrateCropDataOnPlaceSystem extends EntityEventSystem<EntityStore, PlaceBlockEvent> {

    private static final HytaleLogger LOGGER = HytaleLogger.forEnclosingClass();

    private final ComponentType<ChunkStore, MghgCropData> cropDataType;

    public MghgRehydrateCropDataOnPlaceSystem(
            @Nonnull ComponentType<ChunkStore, MghgCropData> cropDataType
    ) {
        super(PlaceBlockEvent.class);
        this.cropDataType = cropDataType;
    }

    @Override
    public @NonNull Class<PlaceBlockEvent> getEventType() {
        return PlaceBlockEvent.class;
    }

    @Override
    public void handle(
            int index,
            @Nonnull ArchetypeChunk<EntityStore> archetypeChunk,
            @Nonnull Store<EntityStore> store,
            @Nonnull CommandBuffer<EntityStore> commandBuffer,
            @Nonnull PlaceBlockEvent event
    ) {
        ItemStack inHand = event.getItemInHand();
        if (inHand == null) return;

        MghgCropMeta meta = inHand.getFromMetadataOrNull(MghgCropMeta.KEY);
        if (meta == null) return;

        // El place de blocks usa el blockKey del item
        String expectedBlockKey = inHand.getBlockKey();
        if (expectedBlockKey == null) return;

        Vector3i pos = event.getTargetBlock();

        // Copiamos valores para el lambda
        final int size = meta.getSize();
        final ClimateMutation climate = parseClimate(meta.getClimate());
        final RarityMutation rarity = parseRarity(meta.getRarity());

        final World world = commandBuffer.getExternalData().getWorld();

        // PlaceBlockEvent se dispara ANTES de colocar (BlockPlaceUtils). Esto corre DESPUÉS.
        world.execute(() -> applyAfterPlace(world, expectedBlockKey, pos, size, climate, rarity));
    }

    private void applyAfterPlace(
            @Nonnull World world,
            @Nonnull String expectedBlockKey,
            @Nonnull Vector3i pos,
            int size,
            @Nonnull ClimateMutation climate,
            @Nonnull RarityMutation rarity
    ) {
        long chunkIndex = ChunkUtil.indexChunkFromBlock(pos.x, pos.z);
        Ref<ChunkStore> chunkRef = world.getChunkStore().getChunkReference(chunkIndex);
        if (chunkRef == null || !chunkRef.isValid()) return;

        Store<ChunkStore> chunkStore = world.getChunkStore().getStore();
        WorldChunk worldChunk = chunkStore.getComponent(chunkRef, WorldChunk.getComponentType());
        if (worldChunk == null) return;

        // Validar que realmente se colocó el bloque esperado (y no se canceló/overrideó)
        int placedId = worldChunk.getBlock(pos.x, pos.y, pos.z);
        if (placedId == 0) return;

        BlockType placedType = BlockType.getAssetMap().getAsset(placedId);
        if (placedType == null || !expectedBlockKey.equals(placedType.getId())) {
            return;
        }

        // Tiempo de juego (Instant) para lastMutationRoll
        Instant now = world.getEntityStore()
                .getStore()
                .getResource(WorldTimeResource.getResourceType())
                .getGameTime();

        // Merge: si ya tenía holder por alguna razón, lo respetamos
        Holder<ChunkStore> holder = worldChunk.getBlockComponentHolder(pos.x, pos.y, pos.z);
        if (holder == null) {
            holder = ChunkStore.REGISTRY.newHolder();
        }

        holder.putComponent(
                this.cropDataType,
                new MghgCropData(size, climate, rarity, now)
        );

        // Esto crea/actualiza el BlockState entity del bloque (persistente) sin tocar FarmingBlock
        worldChunk.setState(pos.x, pos.y, pos.z, holder);

        LOGGER.atFine().log(
                "Rehydrated MGHG_CropData on place at %d,%d,%d (block=%s size=%d climate=%s rarity=%s)",
                pos.x, pos.y, pos.z, expectedBlockKey, size, climate.name(), rarity.name()
        );
    }

    private static ClimateMutation parseClimate(String s) {
        if (s == null || s.isBlank()) return ClimateMutation.NONE;
        try {
            return ClimateMutation.valueOf(s.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            return ClimateMutation.NONE;
        }
    }

    private static RarityMutation parseRarity(String s) {
        if (s == null || s.isBlank()) return RarityMutation.NONE;
        try {
            return RarityMutation.valueOf(s.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            return RarityMutation.NONE;
        }
    }

    @Override
    public @Nullable Query<EntityStore> getQuery() {
        return Archetype.empty();
    }
}
